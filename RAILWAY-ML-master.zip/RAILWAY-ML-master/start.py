import os 
import sys
os.system('python Zone_classifier_etc.py')
os.system('python deaprtment_classifier.py')
os.system('python print_result.py')